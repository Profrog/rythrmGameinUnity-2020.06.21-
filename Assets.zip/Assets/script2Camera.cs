﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;

public class script2Camera : MonoBehaviour //it is shwow to me where mouse poiter for game
{
    // Start is called before the first frame update


    private Camera camera1; //it is in main camera
    private GameObject mousepointer1;
    private float cussorSpeed1 = 10;

    public void inStart1()
    {
        camera1 = this.transform.gameObject.GetComponentInChildren(typeof(Camera)) as Camera;
        string[] guids = AssetDatabase.FindAssets("mousePointer1", new[] { "Assets/prefab1" }); //showing list; 
        string assetPath3 = AssetDatabase.GUIDToAssetPath(guids[0]);
        Object text2 = AssetDatabase.LoadAssetAtPath<Object>(assetPath3);

        if (text2 == null)
        {
            Debug.Log("mousepointer is error, please check prefab and find mousePointer1");
        }

        mousepointer1 = Instantiate(text2) as GameObject;
        mousepointer1.transform.localScale = new Vector3(this.transform.localScale.x , this.transform.localScale.y );
        mousepointer1.transform.position = new Vector3(0, 0, -1);
    }
   
    public void getMouseClick1()
    {
        if (Input.GetMouseButton(0)) //mousecontroller object need gamecontroller, and it's used in here
        {
            CharacterController controller1 = mousepointer1.GetComponent<CharacterController>();
            Vector2 moveDirection = camera1.ScreenToWorldPoint(Input.mousePosition) - mousepointer1.transform.position;
            controller1.Move(moveDirection * Time.deltaTime * cussorSpeed1); 
        }
    }

    void Start()
    {
        inStart1();
    }

    // Update is called once per frame
    void Update()
    {
        getMouseClick1();   
    }
}
