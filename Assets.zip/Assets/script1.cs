﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.UI;

public class script1 : MonoBehaviour
{


    //often using in makeMusicList_musiclist()
    private int musicNum = 200;
    private string musicPath1 = "Assets/music1";
    private string musicIcon1 = "music1";
    private float music1Scale1 = 5000;
    //

    //often using in makeMusicList()
    private string prefabPath1 = "Assets/prefab1";
    private string boardIcon1 = "platform1";
    private GameObject[] musicArray1;
    private float music1x;
    private float music1y; //showing space of music data of showing
    private Object text2; //it is used for emptyobject,has no huge mean
    //

    //using in callbyChild
    private AudioSource audio1;
    private int button1 = 0;
    //

    //using in playTheSong1//
    private int currentPitch = 0;
    private int spectrumNum1 = 256;
    private string noteIcon1 = "note1";
    private List<GameObject> notelist1 = new List<GameObject>();
    private float x1;
    private float y1;
    //



    //using in all
    private GameObject platform1;
    private Vector3 mousePosition1;
    private List<Object> musiclist1 = new List<Object>();
    private AudioClip[] musiclist2;
    private GameObject note1;
   
    private float thisWidth1;
    private float thisHeight1;
    /// 



   public void makeMusicList_musiclist() //make musiclist in asset
    {
        float whereList = -music1Scale1 / 2500;
        audio1 = GetComponent<AudioSource>();
        string[] guids = AssetDatabase.FindAssets("", new[] { musicPath1 }); //in guids, music data go object
        musicNum = guids.Length;
      
        musiclist2 = new AudioClip[musicNum];

        for (int i = 0; i < guids.Length; i++)
        {
            string assetPath = AssetDatabase.GUIDToAssetPath(guids[i]);
            Object asset1 = AssetDatabase.LoadAssetAtPath<Object>(assetPath);
            AudioClip asset2 = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
            

            if (asset1 != null)
            {
                musiclist1.Add(asset1);
                musiclist2[i] = asset2;
            }
        }


     
        Debug.Log(musicNum + "asset music number in" + musicPath1 );
        

        guids = AssetDatabase.FindAssets(musicIcon1, new[] { prefabPath1 }); //showing text of musiclist
        string assetPath2 = AssetDatabase.GUIDToAssetPath(guids[0]);
        text2 = AssetDatabase.LoadAssetAtPath<Object>(assetPath2);

        if (text2 == null)
        {
            Debug.Log(musicIcon1 + " is no where in " + prefabPath1);
        }


        musicArray1 = new GameObject[musicNum];
        for (int i = 0; i < musicNum; i++)
        {   
            musicArray1[i] = Instantiate(text2) as GameObject;
            musicArray1[i].transform.SetParent(this.transform);
            musicArray1[i].name = i + "," + musiclist1[i].name;

            Text musicname1 = musicArray1[i].GetComponentInChildren(typeof(Text)) as Text;
            musicname1.text = musiclist1[i].name;

            musicArray1[i].transform.localScale = new Vector3(thisWidth1 / 100, thisHeight1 / 100);
            musicArray1[i].transform.Translate(this.transform.position.x + music1x * music1Scale1 / 10, this.transform.position.y - whereList * music1y * music1Scale1 / 10, -1);
            whereList--;
        }
    }




   public void makeMusicList()  //making music list, and name list
    {
        string[] guids = AssetDatabase.FindAssets("", new[] { musicPath1 }); //in guids, music data go object

        thisWidth1 = this.transform.gameObject.GetComponent<RectTransform>().rect.width*this.transform.localScale.x;
        thisHeight1 = this.transform.gameObject.GetComponent<RectTransform>().rect.height * this.transform.localScale.y;
        music1x = thisWidth1/music1Scale1;
        music1y = thisHeight1/music1Scale1;

        makeMusicList_musiclist(); //see it up function
        //makemusic list
        
   
        //board

        guids = AssetDatabase.FindAssets(boardIcon1, new[] { prefabPath1 }); //board image
        string assetPath1 = AssetDatabase.GUIDToAssetPath(guids[0]);
        text2 = AssetDatabase.LoadAssetAtPath<Object>(assetPath1);
        if (text2 == null)
        {
            Debug.Log(boardIcon1 + " is no where in " + prefabPath1);
        }

        platform1 = Instantiate(text2) as GameObject;
        platform1.transform.SetParent(this.transform);

        platform1.transform.localScale = new Vector3 (thisWidth1*2, thisHeight1*8);
        platform1.transform.Translate(this.transform.position.x - thisWidth1/3, this.transform.position.y, -1); 
        ///




    }




   public void callbyChild1(string name1) //audio clip play
   {
        string[] indexSplit = name1.Split(',');
        int indexNumber1 = int.Parse(indexSplit[0]);
        
        if (indexNumber1 < musicNum)
        {
            
            audio1.clip = musiclist2[indexNumber1];

            if (audio1.clip == null)
            {
                Debug.Log("audio clip can not played" + indexNumber1);
            }

            else  //if inputting and button value is satisfied, here
            {
                if (button1 == 1)
                {
                    button1 = 0;
                    audio1.Pause();
                    notelist1 = notelist1 = new List<GameObject>();
                }

                else
                {
                    button1 = 1;
                    audio1.Play();                 
                    StartCoroutine(playTheSong1());     
                }
            }
        }
   }





    IEnumerator playTheSong1() //
    {
        while (audio1.isPlaying)
        {
            if (notelist1.Count - 10 > 0)
                Destroy(notelist1[notelist1.Count - 10]);


            float[] spectrum1 = new float[spectrumNum1];
            AudioListener.GetSpectrumData(spectrum1, 0, FFTWindow.Rectangular);

            float result = 0;
            for (int i = 0; i < spectrumNum1; i++)
            {
                result += spectrum1[i];
            }

            result /= spectrumNum1;
            result *= 10000;

            if (currentPitch != (int)(result)) //note is above on board and down
            {
                currentPitch = (int)(result);

                string[] guids;
                guids = AssetDatabase.FindAssets(noteIcon1, new[] { prefabPath1 }); //board image
                string assetPath1 = AssetDatabase.GUIDToAssetPath(guids[0]);
                text2 = AssetDatabase.LoadAssetAtPath<Object>(assetPath1);
                if (text2 == null)
                {
                    Debug.Log(noteIcon1 + " is no where in " + prefabPath1);
                }

                notelist1.Add(Instantiate(text2) as GameObject);
                notelist1[notelist1.Count - 1].transform.SetParent(platform1.transform);
                notelist1[notelist1.Count - 1].transform.localScale = new Vector3(thisWidth1 / 50, thisHeight1 / 70);

                currentPitch %= 7;
                x1 = (currentPitch-3) * (platform1.GetComponent<SpriteRenderer>().bounds.size.x)/7;
                y1 = (platform1.GetComponent<SpriteRenderer>().bounds.size.y)/2; 
                notelist1[notelist1.Count - 1].transform.Translate(platform1.transform.position.x + x1,platform1.transform.position.y, -3);
                notelist1[notelist1.Count - 1].transform.position += new Vector3(0, y1, 0);
            } 
            yield return new WaitForSeconds(0.3f);

        }
    }




    // Start is called before the first frame update
    void Start()
    {
        makeMusicList();
    }


    // Update is called once per frame


    void Update()
    {
      
    }

}
